const list=document.querySelector('#jobs'),search=document.querySelector('#search'),form=document.querySelector('form'),message=document.querySelector('#message');
let request=0;
async function render(){
 const id=++request;
 try{const response=await fetch('/api/jobs?q='+encodeURIComponent(search.value));if(!response.ok)throw new Error('Could not load listings / 暂时无法读取');const jobs=await response.json();if(id!==request)return;list.replaceChildren();
 for(const job of jobs){const article=document.createElement('article'),h=document.createElement('h2'),p=document.createElement('p');h.textContent=job.title;p.textContent=job.company;article.append(h,p);list.append(article);}
 if(!jobs.length)list.textContent='没有匹配内容 / No matches';
 }catch(e){message.textContent=e.message;}
}
search.oninput=render;form.onsubmit=async(event)=>{event.preventDefault();const button=form.querySelector('button');button.disabled=true;try{const response=await fetch('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(form)))});if(!response.ok)throw new Error((await response.json()).error);form.reset();message.textContent='已保存，刷新后再找找看。 / Saved. Refresh and find it again.';await render();}catch(e){message.textContent=e.message;}finally{button.disabled=false;}};render();
