# 我的项目 / My project

服务谁 / Who is it for:
他们要做什么 / What will they do:
我改了什么 / What I changed:
修改前的预测 / My prediction:
实际结果 / What happened:
还想问 Ray / Questions for Ray:
