import test from 'node:test';import assert from 'node:assert/strict';import {makeApp} from './server.mjs';
test('a listing persists and can be searched; invalid input and cross-origin writes fail',async()=>{
 const{server,db}=makeApp();server.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base='http://127.0.0.1:'+server.address().port;
 try{const post=(body,origin=base)=>fetch(base+'/api/jobs',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify(body)});
 assert.equal((await post({title:'Robotics club',company:'Example'})).status,201);
 assert.equal((await(await fetch(base+'/api/jobs?q=Robotics')).json())[0].title,'Robotics club');
 assert.equal((await post({title:'',company:'Example'})).status,400);
 assert.equal((await post({title:'X',company:'Y'},'https://elsewhere.example')).status,403);
 }finally{server.closeAllConnections();await new Promise(r=>server.close(r));db.close();}
});
