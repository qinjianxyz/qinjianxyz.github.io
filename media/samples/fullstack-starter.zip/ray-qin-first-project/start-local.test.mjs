import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {makeApp} from './server.mjs';
import {startLocal} from './start-local.mjs';
test('occupied startup closes its DB, preserves saved work and leaves existing service running',async()=>{
 const dir=mkdtempSync(join(tmpdir(),'studio-start-')),file=join(dir,'jobs.sqlite');
 const existing=createServer((req,res)=>res.end('existing service'));await new Promise(r=>existing.listen(0,'127.0.0.1',r));
 const app=makeApp(file);app.db.prepare('INSERT INTO jobs(title,company) VALUES(?,?)').run('Keep this work','Fictional club');
 try{
  await assert.rejects(startLocal(app,existing.address().port),/Saved data was not deleted/);
  assert.throws(()=>app.db.prepare('SELECT 1'),/closed|open/i);
  assert.equal(await(await fetch('http://127.0.0.1:'+existing.address().port)).text(),'existing service');
  const restarted=makeApp(file);try{await startLocal(restarted,0);const rows=await(await fetch('http://127.0.0.1:'+restarted.server.address().port+'/api/jobs?q=Keep')).json();assert.equal(rows[0].title,'Keep this work');}finally{restarted.server.closeAllConnections();await new Promise(r=>restarted.server.close(r));restarted.db.close();}
 }finally{existing.closeAllConnections();await new Promise(r=>existing.close(r));rmSync(dir,{recursive:true,force:true});}
});
