// Shared by the two local exercises. Never replace a service already running.
export async function startLocal({server,db},port){
 try{
  await new Promise((resolve,reject)=>{
   const failed=error=>{server.off('listening',ready);reject(error);};
   const ready=()=>{server.off('error',failed);resolve();};
   server.once('error',failed);server.once('listening',ready);server.listen(port,'127.0.0.1');
  });
 }catch(error){
  db.close();
  if(error.code==='EADDRINUSE')throw new Error(`端口 ${port} 已被占用。检查是否已经启动了项目；请勿结束不认识的进程。已保存的数据没有删除。 / Port ${port} is in use. Check your existing project terminal; do not stop an unfamiliar process. Saved data was not deleted.`);
  throw error;
 }
}
