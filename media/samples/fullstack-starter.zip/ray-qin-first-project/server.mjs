import { startLocal } from './start-local.mjs';
import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
export function makeApp(database = ':memory:') {
  const db = new DatabaseSync(database);
  db.exec(
    'CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,title TEXT NOT NULL,company TEXT NOT NULL);'
  );
  if (!db.prepare('SELECT 1 FROM jobs LIMIT 1').get())
    db.prepare('INSERT INTO jobs(title,company) VALUES(?,?)').run(
      'Community garden helper / 社区花园助手',
      'Example Club / 示例社团'
    );
  const server = createServer(async (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'"
    );
    const url = new URL(req.url, 'http://localhost');
    if (
      req.method === 'GET' &&
      ['/', '/app.js', '/style.css'].includes(url.pathname)
    ) {
      const file = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
      res.setHeader(
        'Content-Type',
        file.endsWith('.js')
          ? 'text/javascript'
          : file.endsWith('.css')
            ? 'text/css'
            : 'text/html; charset=utf-8'
      );
      return res.end(readFileSync(new URL(file, import.meta.url)));
    }
    // 搜索只读取记录 / A search reads records without changing them.
    if (url.pathname === '/api/jobs' && req.method === 'GET') {
      const q = (url.searchParams.get('q') || '').slice(0, 120);
      return res.end(
        JSON.stringify(
          db
            .prepare(
              'SELECT * FROM jobs WHERE title LIKE ? OR company LIKE ? ORDER BY id DESC'
            )
            .all('%' + q + '%', '%' + q + '%')
        )
      );
    }
    // 发布先检查输入，合格后才保存 / Validate a new listing before saving it.
    if (url.pathname === '/api/jobs' && req.method === 'POST') {
      if (req.headers.origin !== `http://${req.headers.host}`) {
        res.statusCode = 403;
        return res.end(JSON.stringify({ error: 'Local origin required' }));
      }
      try {
        let raw = '';
        for await (const part of req) {
          raw += part;
          if (raw.length > 4096) throw new Error('Too large');
        }
        const { title, company } = JSON.parse(raw);
        if (
          ![title, company].every(
            (v) =>
              typeof v === 'string' && v.trim().length > 0 && v.length <= 120
          )
        )
          throw new Error(
            'Use a title and company, up to 120 characters each.'
          );
        const result = db
          .prepare('INSERT INTO jobs(title,company) VALUES(?,?)')
          .run(title.trim(), company.trim());
        res.statusCode = 201;
        return res.end(JSON.stringify({ id: Number(result.lastInsertRowid) }));
      } catch (e) {
        res.statusCode = 400;
        return res.end(JSON.stringify({ error: e.message }));
      }
    }
    res.statusCode = 404;
    res.end(JSON.stringify({ error: 'Not found' }));
  });
  return { server, db };
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  mkdirSync(new URL('data/', import.meta.url), { recursive: true });
  const app = makeApp(
    fileURLToPath(new URL('data/jobs.sqlite', import.meta.url))
  );
  try {
    await startLocal(app, 8072);
    console.log('Local milestone starter: http://127.0.0.1:8072');
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
