# 秦剑 Ray Qin · 全栈试学
# Your first full-stack project

把这个小项目改成自己的社团或社区信息板：发布一条信息，搜索，刷新后再找到它。
Make this small project your own club or community board: publish a listing, search, and find it again after refreshing.

这是课程的入门起点，包含真实页面、Node 服务器和 SQLite 数据库。不是完整招聘平台，也不是学员作品。账号、申请、权限、AI 和部署属于后续项目内容。
This course starter has a real page, Node server and SQLite database. It is not a finished recruiting platform or a student's work. Accounts, applications, authorization, AI and deployment come later.

## 1. 运行 / Run

需要电脑和 Node.js 24 或更高版本。无需 npm install、账号、API key 或付费。先解压，再在解压后的文件夹打开终端。
Use a computer with Node.js 24 or newer. No npm install, account, API key or payment is needed. Extract the ZIP and open a terminal in the extracted folder.

```sh
node --version
node --test
node server.mjs
```

打开 http://127.0.0.1:8072。保持终端运行；按 Ctrl+C 停止。只用虚构信息，保留默认的本机地址。
Open http://127.0.0.1:8072. Keep the terminal running; Ctrl+C stops it. Use fictional information and keep the default loopback address.

## 2. 用起来 / Try it

发布“周末花园活动”，组织填写“示例社团”。搜索“花园”，再刷新页面。然后试试不存在的词，观察页面显示。
Publish “Weekend garden activity” under “Example Club”. Search “garden”, then refresh. Try a term with no matches and observe the response.

信息不是只画在页面上：页面发送请求，服务器把它写进数据库。数据保存在本文件夹的 data/ 中。停止并重启服务后，再找同一条信息。
The browser sends a request and the server writes to the database in this folder's data/ directory. Stop and restart the service, then find the same listing again.

## 3. 改成你的项目 / Make a change

在 PROJECT.md 写下服务谁、让他们做什么。打开 index.html，把项目名称和一个输入提示改成你的题目。保存文件，刷新页面，再发布和搜索一条信息。
Describe your audience and their task in PROJECT.md. In index.html, change the project name and one input hint. Save, refresh, then publish and search again.

可以让 AI 解释代码。请自己指出改了哪个文件、哪一处，以及它改变了什么。
Ask AI to explain the code if useful. Be ready to identify the file, the change, and its effect yourself.

## 4. 自己检查 / Check your work

- 页面出现了你的项目名称和提示。 / Your name and hint appear on the page.
- 发布、搜索和刷新仍能使用。 / Publishing, searching and refreshing still work.
- 服务重启后，信息仍在。 / The listing survives a server restart.
- 没有匹配信息时，页面给出提示。 / A search with no match gives a message.
- 能说明页面、服务器、数据库各做了什么。 / You can explain the page, server and database roles.

做完后保留截图、PROJECT.md 和修改的文件。遇到问题，记录原本想做什么、输入了什么、看到什么；不需要先把所有问题解决再来交流。
Keep a screenshot, PROJECT.md and the files you changed. If stuck, record your goal, what you entered and what happened. You can bring unfinished work to the conversation.

## 已有经验？ / Already coding?

发布标题 Garden shift、组织 Blue Club；再发布标题 Music rehearsal、组织 Garden Club。分别搜索 Garden 和前后带空格的 ` Garden `，观察差别。找到服务器读取关键词的位置，让搜索忽略前后空格，同时保留标题与组织搜索、空搜索显示全部的行为。修改前先写预测，再测试。
Publish those two fictional listings. Compare Garden with ` Garden `. Find where the server reads the query. Make it ignore surrounding spaces while preserving title-and-organization matching and empty-query behavior. Predict the result before changing and testing it.

## 卡住时 / Troubleshooting

- 找不到 node：先确认已安装 Node，并重新打开终端。 / If node is not found, check the installation and reopen the terminal.
- 找不到 server.mjs：确认终端位于解压后的文件夹。 / If server.mjs is missing, check your terminal's working folder.
- 地址被占用：检查是否已经运行了这个项目；关闭自己先前启动的实例，别停止不认识的程序。 / If the address is busy, check whether your own earlier instance is running. Do not stop an unfamiliar program.
- 网页打不开：终端里的服务需要保持运行，地址用 http://127.0.0.1:8072。 / Keep the server running and use that exact local address.

如果仍卡住，带上 Node 版本和错误原文，删去任何私人信息。
Bring your Node version and the exact error, with private information removed.

## 后续能做什么 / Where this leads

后续全栈项目加入发布者与申请者两个账号、权限、申请处理和作品评审。题目可以是社团招募、技能交流或商家接单；开始前和 Ray 确定范围。
The full-stack pathway adds publisher and applicant accounts, authorization, application handling and project reviews. Adapt the topic to club recruiting, skill exchange or business orders; agree the scope with Ray before starting.

课程、价格与指导说明：https://qinjianxyz.github.io/program.html
直接联系 Ray：https://t.me/rayq_ai
